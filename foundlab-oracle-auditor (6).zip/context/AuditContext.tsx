import React, { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import { AuditLog } from '../types';
import { useToast } from './ToastContext';

interface AuditContextType {
  logs: AuditLog[];
  addLog: (log: Omit<AuditLog, 'timestamp' | 'id'>) => void;
}

const AuditContext = createContext<AuditContextType | undefined>(undefined);

export const AuditProvider = ({ children }: { children: ReactNode }) => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const { showToast } = useToast();

  const addLog = useCallback((log: Omit<AuditLog, 'timestamp' | 'id'>) => {
    const newLog: AuditLog = {
      id: Date.now(),
      ...log,
      timestamp: new Date().toISOString(),
    };
    
    if (log.discrepancy) {
        // Find the most recent log for the same asset to check its last state.
        // In this PoC, the provider checking for discrepancy is CryptoCompare.
        const providerToCheck = 'CryptoCompare';
        const previousLog = logs.find(
            (l) => l.asset === log.asset && l.provider === providerToCheck
        );

        // Show toast only if the state changes from non-discrepant to discrepant.
        if (!previousLog || !previousLog.discrepancy) {
             showToast(`Discrepancy detected in ${log.asset}!`, 'warning');
        }
    }
    
    setLogs((prevLogs) => [newLog, ...prevLogs]);

  }, [logs, showToast]);

  return <AuditContext.Provider value={{ logs, addLog }}>{children}</AuditContext.Provider>;
};

export const useAudit = () => {
  const context = useContext(AuditContext);
  if (context === undefined) {
    throw new Error('useAudit must be used within an AuditProvider');
  }
  return context;
};