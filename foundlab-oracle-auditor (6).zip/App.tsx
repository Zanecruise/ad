
import React from 'react';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { Dashboard } from './components/dashboard/Dashboard';
import { AuditProvider } from './context/AuditContext';
import { ToastProvider } from './context/ToastContext';

function App() {
  return (
    <ToastProvider>
      <AuditProvider>
        <div className="flex flex-col min-h-screen">
          <Header />
          <main className="flex-grow p-4 sm:p-8">
            <Dashboard />
          </main>
          <Footer />
        </div>
      </AuditProvider>
    </ToastProvider>
  );
}

export default App;
