
// Helper function to convert ArrayBuffer to a hexadecimal string.
function bufferToHex(buffer: ArrayBuffer): string {
  return [...new Uint8Array(buffer)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

// Helper to capitalize strings for the rationale.
function capitalize(str: string): string {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// Helper to round numbers to two decimal places.
function round(n: number): number {
  return Math.round(n * 100) / 100;
}

export type VetorReputacional = {
  nome: string;
  peso: number;
  valor: number;
  tempo_meses: number;
};

export type FlagAguda = {
  nome: string;
  peso: number;
};

export type ParametrosSigmoide = {
  k: number;
  x0: number;
};

export type ResultadoScore = {
  score_final: number;
  score_estrutural: number;
  score_reativo: number;
  rationale: {
    vectors: string[];
    flags: string[];
  };
  sdid: string;
};

export async function calculateScore(
  vetores: VetorReputacional[],
  flags: FlagAguda[],
  alpha: number,
  sigmoide: ParametrosSigmoide
): Promise<ResultadoScore> {
  // Spezzatura Engine (T²) - Structural Score
  const spezzaturaSum = vetores.reduce(
    (acc, v) => acc + v.peso * v.valor * Math.pow(v.tempo_meses, 2),
    0
  );
  const scoreEstruturalRaw = Math.log(1 + spezzaturaSum);

  // Normalize the structural score to a 0-100 scale for meaningful combination.
  // We assume a high-quality wallet might have a raw score around 15.
  const MAX_EXPECTED_RAW_STRUCTURAL = 15;
  const normalizedScoreEstrutural = Math.min(100, (scoreEstruturalRaw / MAX_EXPECTED_RAW_STRUCTURAL) * 100);

  // Reactive Score based on Sigmoid function for acute flags.
  // As risk 'x' increases, the score decreases from 100 towards 0.
  const x = flags.reduce((acc, f) => acc + f.peso, 0);
  const reativoScore =
    100 * (1 - 1 / (1 + Math.exp(-sigmoide.k * (x - sigmoide.x0))));

  // Hybrid Composition
  const finalScore = alpha * reativoScore + (1 - alpha) * normalizedScoreEstrutural;

  // Rationale Generation
  const rationaleVetores = vetores.map(
    (v) =>
      `${capitalize(v.nome)} consistente por ${v.tempo_meses} meses com valor observado de ${v.valor}.`
  );
  const rationaleFlags = flags.map(
    (f) => `Flag de risco agudo: ${capitalize(f.nome)} (Impacto: ${f.peso}).`
  );
  
  // SDID Generation using Web Crypto API
  const inputHash = JSON.stringify({ vetores, flags });
  const encoder = new TextEncoder();
  const data = encoder.encode(inputHash);
  const hashBuffer = await window.crypto.subtle.digest("SHA-256", data);
  const hashHex = bufferToHex(hashBuffer);
  const sdid = `sdid:foundlab:0x${hashHex.slice(0, 40)}`;

  return {
    score_final: Math.max(0, Math.min(100, round(finalScore))),
    score_estrutural: round(normalizedScoreEstrutural),
    score_reativo: round(reativoScore),
    rationale: {
      vectors: rationaleVetores,
      flags: rationaleFlags,
    },
    sdid,
  };
}
