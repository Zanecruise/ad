
import { VetorReputacional, FlagAguda } from '../lib/calculateScore';

// Define the input data for the scoring model for each mock wallet.
export const SCORE_MODEL_INPUTS: { [key: string]: { vetores: VetorReputacional[], flags: FlagAguda[] } } = {
  "0xabcdef1234567890abcdef1234567890abcdef12": { // Good wallet
    vetores: [
      { nome: "conformidade regulatória", peso: 2.0, valor: 0.95, tempo_meses: 24 },
      { nome: "atividade em defi", peso: 1.5, valor: 0.8, tempo_meses: 18 },
      { nome: "governança", peso: 1.0, valor: 0.7, tempo_meses: 12 }
    ],
    flags: [],
  },
  "0x00000f0acfeeeddcba1234567890abcdef111111": { // Bad wallet
    vetores: [
       { nome: "atividade em defi", peso: 1.0, valor: 0.5, tempo_meses: 6 },
    ],
    flags: [
      { nome: "interação com mixer", peso: 3.5 },
      { nome: "fonte de fundos sancionada", peso: 5.0 }
    ],
  },
  "0xfaceb00cdead1234567890abcdeffaceb00cdead": { // Neutral/New wallet
    vetores: [
      { nome: "atividade on-chain", peso: 1.0, valor: 0.4, tempo_meses: 3 },
    ],
    flags: [
      { nome: "baixa atividade", peso: 1.0 }
    ],
  }
};

export const COMMON_PARAMS = {
    alpha: 0.4,
    sigmoide: { k: 1.0, x0: 5.0 }
};
