
interface AddressMap {
  [key: string]: {
    [key: string]: string;
  };
}

export const addresses: AddressMap = {
  priceConsumerV3: {
    sepolia: '0xf37F9826f60870894190B5Ffe89138f3ef10079C',
    goerli: '0x46b73aca4AF8D060355beAb7f3C941B214ba0E1F',
  },
};
