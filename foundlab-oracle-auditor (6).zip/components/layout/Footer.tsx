import React from 'react';

export const Footer = () => {
  return (
    <footer className="py-10 px-4 sm:px-8 mt-20 bg-transparent border-t border-gray-700">
      <div className="container mx-auto max-w-screen-xl">
        <div className="flex flex-col items-center space-y-4">
          <p className="text-center text-brand-text-secondary max-w-3xl text-sm">
            FoundLab é uma infraestrutura crítica de reputação e automação reputacional, operando na convergência entre
            TradFi e Web3. Com uma arquitetura modular, não-custodial e auditável, aFoundLab entrega execução de
            score, flags e monitoramento de carteiras digitais em tempo real, garantindo compliance, transparência e
            blindagem regulatória para bancos, fintechs e infraestruturas de missão crítica. Executamos confiança como
            serviço.
          </p>
          
          <div className="flex items-center space-x-2 pt-4">
            <img src="/gcp-logo.svg" alt="Google Cloud Logo" className="h-6" />
            <span className="text-brand-text-secondary text-sm">FoundLab Powered by Google Cloud Web3.</span>
          </div>

          <p className="text-center text-brand-text-secondary italic pt-4 max-w-4xl text-xs">
            Atenção: Esta aplicação é uma Prova de Conceito institucional para fins de demonstração. Os dados de score,
            flags e explicações exibidos são resultados simulados ou provenientes de integrações externas. Nenhuma
            decisão operacional, regulatória ou financeira deve ser tomada com base exclusiva nas informações aqui
            apresentadas. Para uso em produção, consulte sempre as equipes de compliance e jurídico da FoundLab.
          </p>
        </div>
      </div>
    </footer>
  );
};