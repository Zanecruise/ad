
import React from 'react';
import { ConnectWallet } from '../ConnectWallet';

export const Header = () => {
  return (
    <header className="flex items-center justify-between flex-wrap py-4 px-4 sm:px-8 bg-brand-primary border-b border-gray-700">
      <div className="flex items-center mr-5">
        <a href="#" aria-label="Home">
            <img src="/foundlab-logo.svg" alt="FoundLab Logo" className="h-10" />
        </a>
      </div>
      <div className="ml-auto">
        <ConnectWallet />
      </div>
    </header>
  );
};
