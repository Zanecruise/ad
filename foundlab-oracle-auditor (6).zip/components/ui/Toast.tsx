
import React, { useEffect, useState } from 'react';
import { InformationCircleIcon, CheckCircleIcon, ExclamationTriangleIcon, XCircleIcon } from '@heroicons/react/24/solid';

type ToastType = 'info' | 'success' | 'warning' | 'error';

interface ToastProps {
  message: string;
  type: ToastType;
  onDismiss: () => void;
}

const toastConfig = {
  info: {
    bg: 'bg-blue-600',
    icon: <InformationCircleIcon className="h-6 w-6 text-blue-100" />,
  },
  success: {
    bg: 'bg-green-600',
    icon: <CheckCircleIcon className="h-6 w-6 text-green-100" />,
  },
  warning: {
    bg: 'bg-yellow-600',
    icon: <ExclamationTriangleIcon className="h-6 w-6 text-yellow-100" />,
  },
  error: {
    bg: 'bg-red-600',
    icon: <XCircleIcon className="h-6 w-6 text-red-100" />,
  },
};

export const Toast = ({ message, type, onDismiss }: ToastProps) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Animate in
    setVisible(true);

    const timer = setTimeout(() => {
      setVisible(false);
      // Allow time for fade out animation before dismissing
      setTimeout(onDismiss, 300); 
    }, 5000);

    return () => clearTimeout(timer);
  }, [onDismiss]);
  
  const handleDismiss = () => {
      setVisible(false);
      setTimeout(onDismiss, 300);
  }

  const config = toastConfig[type];

  return (
    <div
      className={`flex items-center p-4 text-white rounded-lg shadow-lg min-w-[300px] max-w-sm transition-all duration-300 ${config.bg} ${visible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-full'}`}
      role="alert"
    >
      <div className="flex-shrink-0">{config.icon}</div>
      <div className="ml-3 text-sm font-medium">{message}</div>
      <button
        onClick={handleDismiss}
        type="button"
        className="ml-auto -mx-1.5 -my-1.5 rounded-lg p-1.5 inline-flex h-8 w-8 text-white/70 hover:text-white hover:bg-white/20 focus:ring-2 focus:ring-white/50"
        aria-label="Close"
      >
        <span className="sr-only">Close</span>
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd"></path></svg>
      </button>
    </div>
  );
};
