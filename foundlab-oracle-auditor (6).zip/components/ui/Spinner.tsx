
import React from 'react';

interface SpinnerProps {
    size?: 'sm' | 'md' | 'lg';
}

export const Spinner = ({ size = 'md' }: SpinnerProps) => {
    const sizeClasses = {
        sm: 'h-4 w-4',
        md: 'h-6 w-6',
        lg: 'h-8 w-8',
    };
    
    return (
        <div className={`animate-spin rounded-full border-t-2 border-b-2 border-brand-secondary ${sizeClasses[size]}`}></div>
    );
};
