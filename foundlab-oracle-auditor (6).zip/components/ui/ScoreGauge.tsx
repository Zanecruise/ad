
import React from 'react';

interface ScoreGaugeProps {
  score: number;
  size?: number;
  strokeWidth?: number;
}

export const ScoreGauge = ({ score, size = 160, strokeWidth = 12 }: ScoreGaugeProps) => {
  const center = size / 2;
  const radius = center - strokeWidth;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  const getColor = (s: number) => {
    if (s > 75) return '#00F5D4'; // brand-secondary
    if (s > 40) return '#FBBF24'; // amber-400
    return '#FF4757'; // brand-alert
  };

  const color = getColor(score);

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg className="transform -rotate-90" width={size} height={size}>
        <circle
          className="text-gray-700"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="transparent"
          r={radius}
          cx={center}
          cy={center}
        />
        <circle
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          fill="transparent"
          r={radius}
          cx={center}
          cy={center}
          style={{
            strokeDasharray: circumference,
            strokeDashoffset: offset,
            transition: 'stroke-dashoffset 0.5s ease-out, stroke 0.5s ease-out'
          }}
        />
      </svg>
      <div
        className="absolute inset-0 flex flex-col items-center justify-center"
      >
        <span className="text-sm text-brand-text-secondary">Score</span>
        <span
          className="text-4xl font-bold transition-colors duration-500"
          style={{ color: color }}
        >
          {Math.round(score)}
        </span>
      </div>
    </div>
  );
};
