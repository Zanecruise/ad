
import React from 'react';

interface CompositionBarProps {
  structural: number;
  reactive: number;
}

export const CompositionBar = ({ structural, reactive }: CompositionBarProps) => {
  const total = structural + reactive;
  if (total === 0) {
      return (
           <div className="w-full bg-gray-700 rounded-full h-2.5"></div>
      )
  }
  
  const structuralPercent = (structural / total) * 100;
  const reactivePercent = (reactive / total) * 100;

  return (
    <div>
        <div className="flex w-full h-3 bg-gray-700 rounded-full overflow-hidden">
            <div style={{ width: `${structuralPercent}%` }} className="bg-sky-400 transition-all duration-500"></div>
            <div style={{ width: `${reactivePercent}%` }} className="bg-amber-400 transition-all duration-500"></div>
        </div>
        <div className="flex justify-between text-xs mt-2 text-brand-text-secondary">
            <div className="flex items-center">
                <span className="h-2 w-2 rounded-full bg-sky-400 mr-2"></span>
                <span>Structural: {structural}</span>
            </div>
            <div className="flex items-center">
                <span className="h-2 w-2 rounded-full bg-amber-400 mr-2"></span>
                <span>Reactive: {reactive}</span>
            </div>
        </div>
    </div>
  );
};
