
import React from 'react';

interface SkeletonProps {
    className?: string;
}

export const Skeleton = ({ className = 'h-4 bg-gray-600 rounded' }: SkeletonProps) => {
    return <div className={`animate-pulse ${className}`} />;
};
