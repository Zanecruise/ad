
import React, { useState } from 'react';
import { SparklesIcon } from '@heroicons/react/24/outline';
import { WalletHealthModal } from './dashboard/WalletHealthModal';

export const ConnectWallet = () => {
  const [account, setAccount] = useState<string | null>(null);
  const [balance, setBalance] = useState<string | null>(null);
  const [isModalOpen, setModalOpen] = useState(false);

  const handleConnectWallet = () => {
    const mockAccount = '0x1A2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b';
    const mockBalance = (Math.random() * 2).toFixed(3);
    setAccount(mockAccount);
    setBalance(mockBalance);
  };

  return (
    <>
      {account ? (
        <div className="flex items-center space-x-4">
          <div className="text-right">
            <p className="text-white text-md font-semibold">{balance} ETH</p>
            <p className="text-brand-text-secondary text-sm font-mono">
              {`${account.slice(0, 6)}...${account.slice(
                account.length - 4,
                account.length
              )}`}
            </p>
          </div>
          <button
            onClick={() => setModalOpen(true)}
            className="flex items-center space-x-2 bg-brand-secondary/10 text-brand-secondary font-semibold border border-brand-secondary/30 rounded-md px-3 py-2 hover:bg-brand-secondary/20 transition-colors"
            title="Get AI Security Report"
          >
            <SparklesIcon className="h-5 w-5" />
            <span className="hidden sm:inline">Analisar Segurança com IA</span>
          </button>
        </div>
      ) : (
        <button
          onClick={handleConnectWallet}
          className="bg-brand-primary text-brand-secondary font-bold border border-brand-secondary rounded-md px-4 py-2 hover:bg-brand-secondary/10 transition-colors"
        >
          Connect Wallet
        </button>
      )}
      {account && balance && <WalletHealthModal isOpen={isModalOpen} onClose={() => setModalOpen(false)} walletAddress={account} walletBalance={balance} />}
    </>
  );
}
