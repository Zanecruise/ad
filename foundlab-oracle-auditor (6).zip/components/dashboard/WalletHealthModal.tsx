
import React, { useEffect, useState } from 'react';
import { GoogleGenAI, Type } from '@google/genai';
import { Modal } from '../ui/Modal';
import { Spinner } from '../ui/Spinner';
import { useAudit } from '../../context/AuditContext';
import { AIReport } from '../../types';
import { useClipboard } from '../../hooks/useClipboard';
import { ClipboardDocumentIcon, CheckIcon } from '@heroicons/react/24/outline';


interface WalletHealthModalProps {
  isOpen: boolean;
  onClose: () => void;
  walletBalance: string;
  walletAddress: string;
}

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  console.warn("API_KEY environment variable not set. Wallet Health feature will be disabled.");
}

const getAIPrompt = (walletBalance: string) => `
    You are a helpful Web3 security advisor for the FoundLab platform. A user has connected their wallet. 
    Based on the following data, provide a concise and easy-to-understand 'Wallet Security Report'.
    The report should contain positive points (highlights) and actionable security tips (recommendations).
    Always respond in Brazilian Portuguese.

    Wallet Data:
    - Balance: ${walletBalance} ETH
    - Wallet Age: 2+ years (simulated)
    - Activity: Frequent interaction with major DeFi protocols like Aave, Uniswap, Compound (simulated).
    - Security Flags: No known interaction with sanctioned addresses or phishing sites (simulated).
`;

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        highlights: {
            type: Type.ARRAY,
            description: "Pontos positivos de segurança sobre a carteira.",
            items: { type: Type.STRING }
        },
        recommendations: {
            type: Type.ARRAY,
            description: "Recomendações de segurança acionáveis para o usuário.",
            items: { type: Type.STRING }
        }
    },
    required: ['highlights', 'recommendations']
};


const ReportSkeleton = () => (
    <div className="space-y-4">
        <div className="flex items-center justify-center space-x-3">
            <Spinner />
            <p className="text-brand-text-secondary">Generating AI security report...</p>
        </div>
        <div className="animate-pulse space-y-5 pt-4">
            <div>
                <div className="h-4 bg-gray-600 rounded w-1/4 mb-2"></div>
                <div className="h-3 bg-gray-700 rounded w-full"></div>
                <div className="h-3 bg-gray-700 rounded w-5/6 mt-1"></div>
            </div>
             <div>
                <div className="h-4 bg-gray-600 rounded w-1/3 mb-2"></div>
                <div className="h-3 bg-gray-700 rounded w-full"></div>
                <div className="h-3 bg-gray-700 rounded w-4/6 mt-1"></div>
            </div>
        </div>
    </div>
);

export const WalletHealthModal = ({ isOpen, onClose, walletBalance, walletAddress }: WalletHealthModalProps) => {
  const [report, setReport] = useState<AIReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { addLog } = useAudit();
  
  const reportTextForCopy = report ? `Wallet Security Report\n\nHighlights:\n${report.highlights.map(h => `- ${h}`).join('\n')}\n\nRecommendations:\n${report.recommendations.map(r => `- ${r}`).join('\n')}` : '';
  const { onCopy, hasCopied } = useClipboard(reportTextForCopy);


  useEffect(() => {
    const generateReport = async () => {
      if (!isOpen || !API_KEY) return;
      
      setLoading(true);
      setError('');
      setReport(null);

      try {
        const ai = new GoogleGenAI({ apiKey: API_KEY });
        
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: getAIPrompt(walletBalance),
          config: {
            responseMimeType: "application/json",
            responseSchema,
          }
        });
        
        const parsedReport: AIReport = JSON.parse(response.text);
        setReport(parsedReport);

        addLog({
            queryType: 'AI',
            provider: 'Gemini',
            asset: 'AI Security Report',
            value: 'Success',
            notes: `Report generated for wallet ${walletAddress}`
        });


      } catch (err) {
        console.error("Error generating report:", err);
        setError('Failed to generate AI report. Please try again later.');
        addLog({
            queryType: 'AI',
            provider: 'Gemini',
            asset: 'AI Security Report',
            value: 'Error',
            notes: `Failed to generate report for ${walletAddress}`
        });
      } finally {
        setLoading(false);
      }
    };

    generateReport();
  }, [isOpen, walletBalance, walletAddress, addLog]);

  const renderContent = () => {
    if (loading) {
      return <ReportSkeleton />;
    }
    if (error) {
      return <p className="text-center text-brand-alert">{error}</p>;
    }
    if (report) {
      return (
        <div className="space-y-4">
          <div>
            <h4 className="text-brand-text-primary font-bold mb-2">Destaques</h4>
            <ul className="space-y-1 list-inside">
              {report.highlights.map((item, index) => (
                <li key={`hl-${index}`} className="flex items-start">
                  <span className="mr-2 mt-1.5 text-brand-secondary">&#8226;</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="text-brand-text-primary font-bold mt-4 mb-2">Recomendações</h4>
            <ul className="space-y-1 list-inside">
              {report.recommendations.map((item, index) => (
                 <li key={`rec-${index}`} className="flex items-start">
                  <span className="mr-2 mt-1.5 text-brand-secondary">&#8226;</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      );
    }
    if (!API_KEY) {
        return <p className="text-center text-brand-text-secondary">AI analysis is currently unavailable. The API key is not configured.</p>
    }
    return null;
  };
  
  const modalTitle = (
    <>
      <span>AI Wallet Security Report</span>
      <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-teal-800 text-teal-100">
        Beta
      </span>
      {report && (
        <button onClick={onCopy} className="text-brand-text-secondary hover:text-white transition-colors ml-auto" aria-label="Copy report">
            {hasCopied ? <CheckIcon className="h-5 w-5 text-brand-secondary" /> : <ClipboardDocumentIcon className="h-5 w-5" />}
        </button>
      )}
    </>
  );

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={modalTitle}>
      <div className="text-brand-text-secondary">
          {renderContent()}
      </div>
    </Modal>
  );
};