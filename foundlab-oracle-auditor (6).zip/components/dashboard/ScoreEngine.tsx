
import React, { useState } from 'react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { WalletScore } from '../../types';
import { Spinner } from '../ui/Spinner';
import { CheckCircleIcon, ExclamationTriangleIcon, DocumentArrowDownIcon, UsersIcon, ChartBarIcon } from '@heroicons/react/24/solid';
import { ClipboardDocumentIcon, CheckIcon, SparklesIcon } from '@heroicons/react/24/outline';
import { Skeleton } from '../ui/Skeleton';
import { useClipboard } from '../../hooks/useClipboard';
import { useWalletScoring } from '../../hooks/useWalletScoring';
import { ScoreGauge } from '../ui/ScoreGauge';
import { CompositionBar } from '../ui/CompositionBar';

const ScoreResultSkeleton = () => (
  <div className="pt-4 space-y-4 animate-pulse">
    <Skeleton className="h-5 w-3/4 mb-4" />
    <div className="flex justify-center mb-4">
        <Skeleton className="h-40 w-40 rounded-full" />
    </div>
    <div className="border-t border-gray-600 pt-4">
      <Skeleton className="h-4 w-40 mb-3" />
      <div className="space-y-2">
        <Skeleton className="h-5 w-full" />
        <Skeleton className="h-5 w-11/12" />
      </div>
    </div>
    <Skeleton className="h-3 w-full mt-2" />
  </div>
);


const getFlagStyle = (flag: string) => {
  const lowerFlag = flag.toLowerCase();
  if (lowerFlag.includes('no aml hit') || lowerFlag.includes('established')) {
    return 'bg-green-800 text-green-100';
  }
  if (lowerFlag.includes('sanctioned') || lowerFlag.includes('mixer') || lowerFlag.includes('risco') || lowerFlag.includes('sancionada') || lowerFlag.includes('phishing')) {
    return 'bg-red-800 text-red-100';
  }
  if (lowerFlag.includes('high volume')) {
      return 'bg-sky-800 text-sky-100';
  }
  return 'bg-yellow-800 text-yellow-100';
};

const ScoreResultCard = ({ result, loading, error }: { result: WalletScore | null; loading: boolean; error: string; }) => {
  const { onCopy, hasCopied } = useClipboard(result?.address || '');
  if (loading) return <ScoreResultSkeleton />;
  if (error) return <div className="text-brand-alert mt-4 p-4 border border-brand-alert/30 rounded-md">{error}</div>;
  if (!result) return null;

  return (
    <div className="pt-4 space-y-4">
      <div className="flex items-center space-x-2 mb-4">
        <p className="font-mono text-sm text-brand-text-secondary truncate" title={result.address}>{result.address}</p>
        <button onClick={onCopy} className="text-brand-text-secondary hover:text-white transition-colors flex-shrink-0" aria-label="Copy address">
            {hasCopied ? <CheckIcon className="h-4 w-4 text-brand-secondary" /> : <ClipboardDocumentIcon className="h-4 w-4" />}
        </button>
      </div>
      
      <div className="flex flex-col items-center">
        <ScoreGauge score={result.score} />
      </div>

      <div className="flex flex-wrap justify-center items-center mt-4 sm:mt-0 gap-2">
          {result.flags.map((flag) => (
            <span
              key={flag}
              className={`text-xs font-semibold px-2.5 py-1 rounded-full ${getFlagStyle(flag)}`}
            >
              {flag}
            </span>
          ))}
      </div>
      
      <div className="border-t border-gray-600 pt-4">
          <h4 className="text-sm text-brand-text-secondary mb-3 flex items-center">
              <ChartBarIcon className="h-4 w-4 mr-2"/>
              Score Composition
          </h4>
          <CompositionBar structural={result.score_details.structural} reactive={result.score_details.reactive} />
      </div>

      <div className="border-t border-gray-600 pt-4">
        <h4 className="text-sm text-brand-text-secondary">Rationale Tokens:</h4>
        <ul className="space-y-2 pt-2">
          {result.rationale.vectors.map((item: string) => (
            <li key={item} className="flex items-start">
              <CheckCircleIcon className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
              <span>{item}</span>
            </li>
          ))}
           {result.rationale.flags.map((item: string) => (
            <li key={item} className="flex items-start">
              <ExclamationTriangleIcon className="h-5 w-5 text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>

      <p className="text-xs text-gray-500 pt-2 truncate">SDID: {result.sdid}</p>
    </div>
  );
};

const foundLabLogoBase64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAAAZCAYAAADHXotLAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH6AYEESEzI29tYQAAArNJREFUaN7dWF1PDGEU/907M8zuzC6wsLAgsOx9WdYlWFB2FhY2LHyALCzsuNmd2X3uzGTv9N5NN5M0pYk3O+k0aebpqd+p+3T1/B4IgiAIgiAIgiAIAoKkM51tNjf9Nf0m36c/S33f+l97w42Y8x/V1dVT09PT19TUDG3t7ezsLGlpaV3w/1lA5vj4+Bw3k8kkk0wmQ/nS/8m4mG9vb1sIIXb29/c3jYyMdDwez1itVu/f39/fO52O+Xx+dXh4uA8I2vX19e27u7svBwcH9/b2dmxvb29ubl5fX18/oOuOjo5+cHDwKzC3tLT0mzerq6sv3t7efvX19d2AgKjRaDztdhvIYmJienZ29pWBUHFx8b29vS+VlZVXQAb29vYuLS198fb2Dtrb219WVvZWADKysrLybGxs/D48PLx3d3dEIpEoFAqXwWAwvCAIwmq1egsICG9vb08mk5tWq/ULLo/H82g0+r6/v782Nja0t7d37e3t/f2RkZEhQohhGNe6urpeo9H4Znd398PDw2tGREQGg8F7R0dH39zcXOvr6ztut1sMhUKXpKRkaGhoUFBQUFlZ+UoAOHbs2AHAoUOHtra2thcvXgQAXFxcBADf//4lAODSpUuApKTk/v7+1atXgwDu3LkTAPjwww+hUCg4ODgEBQUZHR1dWVn5Wk9Pz+rq6srKysra2tpjx441NDRcePdu/w8A4sSJExAE4ffv38+ePWtra2sA4NChQ+fOnQMARkdHh4SETE1NffHixQDAnTt3IiMjI0eO7OzsjI+Pj4yMjIqKcnJycnJyciUlJcXFxRkeHn716tWrZs2agYGBERERUVFRhYaGEkKEKIr+/v5Wq3VxcfFrr9e7zs7OHwJgMpn8fnx8/MHBwe/u7m40Go3ZbH4tCLquq6uL/319fT0wMCAIgiAIgiAIgiAIgvD5fQEnxSkPGo4IiwAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAyNC0wNi0wNFQxNzoyOTozNSswMDowMCE0Lq8AAAAldEVYdGRhdGU6bW9kaWZ5ADIwMjNC0wNi0wNFQxNzoyOTozNSswMDowMOVLc4UAAAAASUVORK5CYII=';

export const ScoreEngine = () => {
  const [isCompareMode, setCompareMode] = useState(false);
  
  const { result: resultA, loading: loadingA, error: errorA, address: addressA, setAddress: setAddressA, findScore: findScoreA, runSimulation: runSimulationA, clearState: clearA } = useWalletScoring();
  const { result: resultB, loading: loadingB, error: errorB, address: addressB, setAddress: setAddressB, findScore: findScoreB, runSimulation: runSimulationB, clearState: clearB } = useWalletScoring();

  const handleCompareToggle = (checked: boolean) => {
    setCompareMode(checked);
    if (!checked) {
      clearB();
    }
  };

  const handleGenerateReport = () => {
    if (!resultA) return;
    const doc = new jsPDF();
    const wallet = resultA;

    doc.addImage(foundLabLogoBase64, 'PNG', 14, 12, 40, 10);
    doc.setFontSize(22);
    doc.setTextColor('#1A212B');
    doc.text("Wallet Due Diligence Report", 105, 18, { align: 'center' });
    doc.setFontSize(10);
    doc.setTextColor('#555');
    doc.text(`Report generated: ${new Date().toLocaleString()}`, 200, 30, { align: 'right' });
    doc.line(14, 32, 200, 32);

    autoTable(doc, {
        startY: 38,
        theme: 'plain',
        body: [
            [{ content: 'Wallet Address:', styles: { fontStyle: 'bold' } }, { content: wallet.address, styles: { font: 'courier' } }],
            [{ content: 'Reputation Score:', styles: { fontStyle: 'bold' } }, { content: wallet.score.toString(), styles: { fontStyle: 'bold', fontSize: 16, textColor: wallet.score > 75 ? '#00F5D4' : wallet.score > 50 ? '#FFC107' : '#FF4757' } }],
            [{ content: 'SDID:', styles: { fontStyle: 'bold' } }, { content: wallet.sdid, styles: { fontSize: 8, font: 'courier' } }],
        ],
    });

     autoTable(doc, {
        startY: (doc as any).lastAutoTable.finalY + 5,
        theme: 'plain',
        body: [
            [{ content: 'Score Composition:', styles: { fontStyle: 'bold' } }, 
             `Structural: ${wallet.score_details.structural} | Reactive: ${wallet.score_details.reactive}`
            ],
        ],
    });

    autoTable(doc, {
        startY: (doc as any).lastAutoTable.finalY + 10,
        head: [['Risk Flags']],
        body: wallet.flags.map(f => [f]),
        headStyles: { fillColor: '#232B38' },
    });
    
     autoTable(doc, {
        startY: (doc as any).lastAutoTable.finalY + 10,
        head: [['Rationale Tokens']],
        body: [...wallet.rationale.vectors, ...wallet.rationale.flags].map(e => [e]),
        headStyles: { fillColor: '#232B38' },
    });

    doc.save(`FoundLab_Report_${wallet.address.slice(0, 8)}.pdf`);
  };


  const handleSearch = () => {
    findScoreA();
    if (isCompareMode) {
      findScoreB();
    } else {
        clearB();
    }
  };

  const handleSimulatedTest = () => {
      if(isCompareMode) {
        runSimulationB();
      } else {
        clearB();
        runSimulationA();
      }
  };

  return (
    <div className="p-5 bg-brand-card rounded-md w-full">
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h3 className="text-xl font-bold text-brand-text-primary">FoundLab Score Engine</h3>
                <p className="text-xs text-brand-text-secondary mt-1 max-w-lg">
                    This PoC demonstrates our direct risk model. The full FoundLab platform provides a comprehensive risk profile by aggregating data from our advanced modules: Sherlock (Compliance) and Sentinela (Dynamic Triggers).
                </p>
            </div>
            <label htmlFor="compare-toggle" className="flex items-center cursor-pointer mt-2 sm:mt-0 flex-shrink-0">
                <UsersIcon className="h-5 w-5 mr-2 text-brand-text-secondary"/>
                <span className="mr-3 text-sm font-medium text-brand-text-secondary">Compare Mode</span>
                <div className="relative">
                    <input type="checkbox" id="compare-toggle" className="sr-only" checked={isCompareMode} onChange={(e) => handleCompareToggle(e.target.checked)} />
                    <div className="block bg-gray-600 w-10 h-6 rounded-full"></div>
                    <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${isCompareMode ? 'translate-x-full bg-brand-secondary' : ''}`}></div>
                </div>
            </label>
        </div>
        
        <div className={`grid grid-cols-1 ${isCompareMode ? 'md:grid-cols-2' : ''} gap-4`}>
            <input
                type="text"
                placeholder="Try mock: 0xabcdef... or use simulation"
                value={addressA}
                onChange={(e) => setAddressA(e.target.value)}
                className="w-full bg-gray-900 border border-gray-600 rounded-md px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-brand-secondary"
            />
            {isCompareMode && (
                <input
                    type="text"
                    placeholder="Try mock: 0x00000f... or simulation"
                    value={addressB}
                    onChange={(e) => setAddressB(e.target.value)}
                    className="w-full bg-gray-900 border border-gray-600 rounded-md px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-brand-secondary"
                />
            )}
        </div>
        
        <div className="flex justify-end gap-2">
            {!isCompareMode && resultA && (
                <button
                    onClick={handleGenerateReport}
                    className="flex items-center gap-2 text-sm bg-gray-600 hover:bg-gray-500 text-white font-semibold py-2 px-4 rounded-md transition-colors"
                >
                    <DocumentArrowDownIcon className="h-4 w-4"/>
                    Generate Report
                </button>
            )}
            <button
                onClick={handleSimulatedTest}
                disabled={loadingA || loadingB}
                className="flex items-center gap-2 text-sm bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
                <SparklesIcon className="h-4 w-4" />
                Gerar Teste Simulado
            </button>
            <button
                onClick={handleSearch}
                disabled={loadingA || loadingB || (isCompareMode ? !addressA || !addressB : !addressA)}
                className="flex justify-center items-center bg-brand-secondary text-brand-primary font-bold py-2 px-4 rounded-md hover:bg-teal-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed min-w-[80px]"
            >
                {(loadingA || loadingB) ? <Spinner /> : 'Query'}
            </button>
        </div>

        <div className={`grid grid-cols-1 ${isCompareMode ? 'md:grid-cols-2 md:divide-x md:divide-gray-600' : ''} gap-x-6`}>
             {(loadingA || errorA || resultA) && <ScoreResultCard result={resultA} loading={loadingA} error={errorA} />}
             {isCompareMode && (loadingB || errorB || resultB) && <div className="md:pl-6 pt-4 md:pt-0"><ScoreResultCard result={resultB} loading={loadingB} error={errorB} /></div>}
        </div>
      </div>
    </div>
  );
};
