import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useAudit } from '../../context/AuditContext';
import { VscVmActive, VscLink, VscWarning } from 'react-icons/vsc';
import { Spinner } from '../ui/Spinner';
import { Tooltip } from '../ui/Tooltip';
import { useClipboard } from '../../hooks/useClipboard';
import { ClipboardDocumentIcon, CheckIcon } from '@heroicons/react/24/outline';
import { formatDistanceToNow } from 'date-fns';
import { Skeleton } from '../ui/Skeleton';

interface PriceFeedCardProps {
  contractAddress: string;
  assetName: string;
  fallbackSymbol: string;
}

const defaultInitialPrices: { [key: string]: number } = {
    'ETH': 3500,
    'BTC': 65000,
};

const PriceFeedCardSkeleton = () => (
    <div className="p-5 bg-brand-card rounded-md w-full min-w-[320px] flex flex-col">
        <div className="flex-grow space-y-4">
            <Skeleton className="h-7 w-1/2" />
            <div className="flex justify-between my-4">
                <div className="space-y-1">
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-10 w-32" />
                </div>
                <div className="space-y-1 items-end flex flex-col">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-6 w-20" />
                </div>
            </div>
        </div>
         <div className="pt-4 border-t border-gray-600 space-y-3">
             <Skeleton className="h-5 w-full" />
             <Skeleton className="h-5 w-full" />
             <Skeleton className="h-4 w-full" />
         </div>
    </div>
);

export const PriceFeedCard = ({ contractAddress, assetName, fallbackSymbol }: PriceFeedCardProps) => {
  const { addLog } = useAudit();
  const initialPrice = defaultInitialPrices[fallbackSymbol] || 500;
  
  const [isLoading, setIsLoading] = useState(true);
  const [chainlinkPrice, setChainlinkPrice] = useState<number | null>(null);
  const [lastUpdatedAt, setLastUpdatedAt] = useState<Date | null>(null);
  const [roundId, setRoundId] = useState<number>(Math.floor(Math.random() * 100000));
  const [fallbackPrice, setFallbackPrice] = useState<number | null>(null);
  const [discrepancy, setDiscrepancy] = useState(false);
  
  const lastLoggedRoundId = useRef(0);
  const { onCopy, hasCopied } = useClipboard(contractAddress);

  const fetchFallback = useCallback(async (currentChainlinkPrice: number) => {
    setFallbackPrice(null);
    setDiscrepancy(false);
    try {
      const response = await fetch(`https://min-api.cryptocompare.com/data/price?fsym=${fallbackSymbol}&tsyms=USD`);
      if (!response.ok) throw new Error('Network response was not ok');
      const data = await response.json();
      const price = data.USD;
      setFallbackPrice(price);

      const percentageDiff = Math.abs((currentChainlinkPrice - price) / currentChainlinkPrice) * 100;
      const isDivergent = percentageDiff > 0.5;
      setDiscrepancy(isDivergent);

      addLog({
        queryType: 'PriceFeed',
        provider: 'CryptoCompare',
        asset: assetName,
        value: price.toFixed(2),
        discrepancy: isDivergent,
        notes: `Discrepancy Check vs CL: ${percentageDiff.toFixed(2)}%`,
      });
    } catch (error) {
      console.error('Fallback price fetch error:', error);
      setFallbackPrice(0);
       addLog({
        queryType: 'PriceFeed',
        provider: 'CryptoCompare',
        asset: assetName,
        value: 'Error',
        discrepancy: true,
        notes: 'Failed to fetch fallback price.',
      });
    }
  }, [addLog, assetName, fallbackSymbol]);
  
  useEffect(() => {
    if (chainlinkPrice !== null && roundId > lastLoggedRoundId.current) {
        lastLoggedRoundId.current = roundId;
        addLog({
            queryType: 'PriceFeed',
            provider: 'Chainlink',
            asset: assetName,
            value: chainlinkPrice.toFixed(2),
            discrepancy: false,
            notes: `Round ID: ${roundId}`,
        });
        fetchFallback(chainlinkPrice);
    }
  }, [roundId, chainlinkPrice, addLog, fetchFallback, assetName]);

  useEffect(() => {
    const initTimeout = setTimeout(() => {
      setChainlinkPrice(initialPrice);
      setLastUpdatedAt(new Date());
      setIsLoading(false);
    }, 1200 + Math.random() * 500);

    const interval = setInterval(() => {
      setChainlinkPrice(prevPrice => {
        if (prevPrice === null) return initialPrice;
        const change = (Math.random() - 0.5) * (prevPrice * 0.001);
        return prevPrice + change;
      });
      setRoundId(prevId => prevId + 1);
      setLastUpdatedAt(new Date());
    }, 5000);

    return () => {
      clearTimeout(initTimeout);
      clearInterval(interval);
    }
  }, [initialPrice]);
  
  if (isLoading) {
    return <PriceFeedCardSkeleton />;
  }

  return (
    <div className="p-5 bg-brand-card rounded-md w-full min-w-[320px] flex flex-col">
      <div className="flex-grow">
        <h3 className="text-xl font-bold text-brand-text-primary">{assetName}</h3>
        <div className="flex justify-between my-4">
          <div className="flex flex-col items-start space-y-0">
            <span className="text-sm text-brand-text-secondary">Chainlink</span>
            <span className="text-4xl font-bold text-brand-secondary">
              {chainlinkPrice ? `$${chainlinkPrice.toFixed(2)}` : <Spinner />}
            </span>
          </div>
          <div className="flex flex-col items-end space-y-0">
            <span className="text-sm text-brand-text-secondary">Fallback (CC)</span>
            <div className="flex items-center space-x-2">
              {discrepancy && (
                <Tooltip message="Discrepancy > 0.5%">
                  <VscWarning className="text-brand-alert" />
                </Tooltip>
              )}
              <span className={`text-lg font-bold ${discrepancy ? 'text-brand-alert' : 'text-brand-text-primary'}`}>
                {fallbackPrice !== null ? `$${fallbackPrice.toFixed(2)}` : <Spinner size="sm" />}
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="pt-4 border-t border-gray-600 space-y-2">
        <div className="flex justify-between items-center text-xs">
            <span className="text-brand-text-secondary">Last Update</span>
            <span className="text-brand-text-primary font-medium">
                {lastUpdatedAt ? formatDistanceToNow(lastUpdatedAt, { addSuffix: true }) : '...'}
            </span>
        </div>
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <VscLink className="text-brand-text-secondary" />
            <span className="text-sm text-brand-text-secondary">Contract</span>
          </div>
          <div className="flex items-center gap-2">
            <a
              href={`https://sepolia.etherscan.io/address/${contractAddress}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs bg-gray-700 text-brand-text-secondary px-2 py-1 rounded hover:text-brand-secondary transition-colors"
            >
              {`${contractAddress.substring(0, 6)}...${contractAddress.substring(38)}`}
            </a>
            <button onClick={onCopy} className="text-brand-text-secondary hover:text-white transition-colors" aria-label="Copy address">
                {hasCopied ? <CheckIcon className="h-4 w-4 text-brand-secondary" /> : <ClipboardDocumentIcon className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <VscVmActive className="text-brand-text-secondary" />
            <span className="text-sm text-brand-text-secondary">Chainlink Round ID</span>
          </div>
          <span className="text-sm text-brand-text-primary">{roundId ? roundId.toString() : '...'}</span>
        </div>
      </div>
    </div>
  );
};