import React from 'react';
import Papa from 'papaparse';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { useAudit } from '../../context/AuditContext';
import { DocumentMagnifyingGlassIcon } from '@heroicons/react/24/outline';


export const AuditLogTable = () => {
  const { logs } = useAudit();

  const handleExportCSV = () => {
    if (!logs || logs.length === 0) return;
    const csvData = logs.map(log => ({
      Timestamp: new Date(log.timestamp).toLocaleString(),
      Provider: log.provider,
      'Asset/Query': log.asset,
      Value: log.value,
      'Discrepancy': log.discrepancy ? 'YES' : 'NO',
      Notes: log.notes,
    })).reverse();
    const csv = Papa.unparse(csvData);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', 'foundlab_audit_log.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPDF = () => {
    if (!logs || logs.length === 0) return;
    const doc = new jsPDF();
    const tableColumn = ["Timestamp", "Provider", "Asset/Query", "Value", "Notes"];
    const tableRows: any[] = [];

    logs.slice().reverse().forEach(log => {
      const logData = [
        new Date(log.timestamp).toLocaleString(),
        log.provider,
        log.asset,
        typeof log.value === 'number' ? `$${log.value.toFixed(2)}` : log.value.toString(),
        log.notes,
      ];
      tableRows.push(logData);
    });
    
    doc.text("FoundLab - Oracle Audit Report", 14, 15);
    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 20,
      theme: 'grid',
      headStyles: { fillColor: [35, 43, 56] },
    });
    doc.save('foundlab_audit_report.pdf');
  };

  const providerColor = (provider: string) => {
    switch(provider) {
        case 'Chainlink': return 'bg-blue-800 text-blue-100';
        case 'CryptoCompare': return 'bg-purple-800 text-purple-100';
        case 'FoundLab': return 'bg-teal-800 text-teal-100';
        default: return 'bg-gray-700 text-gray-200';
    }
  }
  
  const hasLogs = logs && logs.length > 0;

  return (
    <div className="p-5 bg-brand-card rounded-md w-full mt-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
        <h3 className="text-xl font-bold text-brand-text-primary">
          Real-Time Audit Log
        </h3>
        <div className="flex space-x-2">
          <button onClick={handleExportCSV} disabled={!hasLogs} className="text-sm bg-gray-600 hover:bg-gray-500 text-white font-semibold py-1.5 px-3 rounded disabled:opacity-50 disabled:cursor-not-allowed transition-colors">Export CSV</button>
          <button onClick={handleExportPDF} disabled={!hasLogs} className="text-sm bg-gray-600 hover:bg-gray-500 text-white font-semibold py-1.5 px-3 rounded disabled:opacity-50 disabled:cursor-not-allowed transition-colors">Export PDF</button>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-brand-text-secondary uppercase bg-brand-card">
            <tr>
              <th scope="col" className="px-4 py-3">Timestamp</th>
              <th scope="col" className="px-4 py-3">Provider</th>
              <th scope="col" className="px-4 py-3">Asset/Query</th>
              <th scope="col" className="px-4 py-3">Value</th>
              <th scope="col" className="px-4 py-3">Notes</th>
            </tr>
          </thead>
          <tbody>
            {hasLogs ? logs.map((log) => (
              <tr key={log.id} className="border-b border-gray-700 hover:bg-gray-700/50">
                <td className="px-4 py-2 text-xs">{new Date(log.timestamp).toLocaleTimeString()}</td>
                <td className="px-4 py-2">
                  <span className={`text-xs font-semibold mr-2 px-2.5 py-0.5 rounded ${providerColor(log.provider)}`}>
                    {log.provider}
                  </span>
                </td>
                <td className="px-4 py-2">{log.asset}</td>
                <td className={`px-4 py-2 font-bold ${log.discrepancy ? 'text-brand-alert' : 'inherit'}`}>
                  {typeof log.value === 'number' ? `$${Number(log.value).toFixed(2)}` : log.value}
                </td>
                <td className="px-4 py-2 text-xs">{log.notes}</td>
              </tr>
            )) : (
                <tr>
                    <td colSpan={5} className="text-center py-12">
                        <div className="flex flex-col items-center space-y-3 text-brand-text-secondary">
                            <DocumentMagnifyingGlassIcon className="h-10 w-10" />
                            <p className="font-semibold text-lg">No Activity Recorded</p>
                            <p className="text-sm">Query a wallet score or watch price feeds to begin the audit.</p>
                        </div>
                    </td>
                </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};