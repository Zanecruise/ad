
import React from 'react';
import { PriceFeedCard } from './PriceFeedCard';
import { ScoreEngine } from './ScoreEngine';
import { AuditLogTable } from './AuditLogTable';
import { addresses } from '../../constants';

export const Dashboard = () => {
  return (
    <div className="flex flex-col space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        <PriceFeedCard
          contractAddress={addresses.priceConsumerV3['sepolia']}
          assetName="ETH / USD"
          fallbackSymbol="ETH"
        />
        <PriceFeedCard
          contractAddress={addresses.priceConsumerV3['goerli']}
          assetName="BTC / USD"
          fallbackSymbol="BTC"
        />
      </div>

      <ScoreEngine />

      <AuditLogTable />
    </div>
  );
};