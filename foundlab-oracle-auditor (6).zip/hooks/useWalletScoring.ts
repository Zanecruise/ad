
import { useState, useCallback } from 'react';
import { useAudit } from '../context/AuditContext';
import { WalletScore } from '../types';
import { calculateScore, VetorReputacional, FlagAguda } from '../lib/calculateScore';
import { SCORE_MODEL_INPUTS, COMMON_PARAMS } from '../data/scoreMock';

export const useWalletScoring = () => {
    const [address, setAddress] = useState('');
    const [result, setResult] = useState<WalletScore | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const { addLog } = useAudit();

    const clearState = useCallback(() => {
        setAddress('');
        setResult(null);
        setLoading(false);
        setError('');
    }, []);

    const processScoreCalculation = useCallback(async (
        walletAddress: string,
        vetores: VetorReputacional[],
        flags: FlagAguda[],
        isSimulated: boolean = false
    ) => {
        try {
            const resultData = await calculateScore(
                vetores,
                flags,
                COMMON_PARAMS.alpha,
                COMMON_PARAMS.sigmoide
            );

            const walletScore: WalletScore = {
                address: walletAddress,
                score: resultData.score_final,
                flags: flags.map(f => f.nome.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())),
                rationale: resultData.rationale,
                sdid: resultData.sdid,
                score_details: {
                    structural: resultData.score_estrutural,
                    reactive: resultData.score_reativo,
                }
            };

            setResult(walletScore);
            addLog({
                queryType: 'ExternalAPI',
                provider: 'FoundLab',
                asset: `Score for ${walletAddress.substring(0, 8)}... ${isSimulated ? '(Simulated)' : ''}`,
                value: walletScore.score,
                notes: `Flags: ${walletScore.flags.join(', ') || 'None'}`,
            });
        } catch (e) {
            console.error("Scoring error:", e);
            setError("An error occurred during score calculation.");
        } finally {
            setLoading(false);
        }
    }, [addLog]);

    const findScore = useCallback(async () => {
        if (!address) return;
        setLoading(true);
        setError('');
        setResult(null);

        await new Promise(resolve => setTimeout(resolve, 800));

        const inputData = SCORE_MODEL_INPUTS[address.toLowerCase()];

        if (inputData) {
            await processScoreCalculation(address, inputData.vetores, inputData.flags);
        } else {
            setError(`Wallet address not found. Try one of the mock addresses: 0xabcdef..., 0x00000f..., or 0xfaceb0...`);
            setLoading(false);
        }
    }, [address, processScoreCalculation]);
    
    const runSimulation = useCallback(async () => {
        setLoading(true);
        setError('');
        setResult(null);

        const randomAddress = '0x' + [...Array(40)].map(() => Math.floor(Math.random() * 16).toString(16)).join('');
        setAddress(randomAddress);

        const vetorNomes = ["conformidade", "atividade on-chain", "governança", "liquidez"];
        const numVetores = Math.floor(Math.random() * 3) + 1;
        const vetores: VetorReputacional[] = Array.from({ length: numVetores }, (_, i) => ({
            nome: vetorNomes[i % vetorNomes.length],
            peso: Math.random() * 2 + 0.5,
            valor: Math.random() * 0.9 + 0.1,
            tempo_meses: Math.floor(Math.random() * 36) + 1,
        }));

        const flagNomes = ["interação com mixer", "endereço sancionado", "conexão com phishing", "alta volatilidade"];
        const numFlags = Math.random() > 0.6 ? Math.floor(Math.random() * 2) + 1 : 0;
        const flags: FlagAguda[] = [];
        if (numFlags > 0) {
            const shuffledFlags = [...flagNomes].sort(() => 0.5 - Math.random());
            for (let i = 0; i < numFlags; i++) {
                flags.push({ nome: shuffledFlags[i], peso: Math.random() * 4 + 1.0 });
            }
        }
        
        await new Promise(resolve => setTimeout(resolve, 800));
        await processScoreCalculation(randomAddress, vetores, flags, true);

    }, [processScoreCalculation]);


    return { address, setAddress, result, loading, error, findScore, runSimulation, clearState };
};
