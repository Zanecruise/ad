import { useState, useCallback, useEffect } from 'react';

export const useClipboard = (textToCopy: string, timeout = 1500) => {
  const [hasCopied, setHasCopied] = useState(false);

  const onCopy = useCallback(() => {
    if (!textToCopy) return;
    navigator.clipboard.writeText(textToCopy).then(() => {
      setHasCopied(true);
    }).catch(err => {
      console.error('Failed to copy text: ', err);
    });
  }, [textToCopy]);

  useEffect(() => {
    if (hasCopied) {
      const timer = setTimeout(() => {
        setHasCopied(false);
      }, timeout);
      return () => clearTimeout(timer);
    }
  }, [hasCopied, timeout]);

  return { onCopy, hasCopied };
};
