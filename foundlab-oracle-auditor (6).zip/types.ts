
export interface AuditLog {
  id?: number;
  timestamp: string;
  queryType: 'PriceFeed' | 'VRF' | 'ExternalAPI' | 'AI';
  provider: 'Chainlink' | 'CryptoCompare' | 'FoundLab' | 'Gemini';
  asset: string;
  value: string | number;
  discrepancy?: boolean;
  notes: string;
}

export interface WalletScore {
  address: string;
  score: number;
  flags: string[];
  rationale: {
    vectors: string[];
    flags: string[];
  };
  sdid: string;
  score_details: {
      structural: number;
      reactive: number;
  }
}

export interface AIReport {
  highlights: string[];
  recommendations: string[];
}
