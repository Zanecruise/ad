# FoundLab Oracle Auditor - Frontend

This repository contains the frontend Proof-of-Concept (PoC) for the FoundLab Oracle Auditor. It's a React-based web application built with TypeScript, TailwindCSS, and Vite, designed to demonstrate real-time oracle price auditing, wallet scoring, and AI-powered security analysis.

The application runs without a traditional build step, using modern browser features like ES modules and import maps for a fast and simple development experience.

## Features

*   **Real-Time Price Feeds**: Monitors and displays simulated cryptocurrency price feeds, checking for discrepancies against a fallback provider.
*   **Reputation Score Engine**: Scores wallet addresses based on a hybrid model of structural and reactive factors. Includes single wallet analysis and a comparison mode.
*   **AI-Powered Security Analysis**: Uses the Google Gemini API to generate a security report for a connected wallet, providing highlights and actionable recommendations.
*   **Comprehensive Audit Log**: Logs all significant actions (price checks, score queries, AI analysis) in a real-time table.
*   **Export Functionality**: Allows users to export audit logs and wallet reports as PDF or CSV files.
*   **Modern UI/UX**: Features a clean, dark-themed interface with responsive components, skeleton loaders, toasts, and modals.

## Getting Started

### Prerequisites

*   A modern web browser that supports ES Modules (e.g., Chrome, Firefox, Edge).
*   A code editor like VS Code.
*   A live server to serve the `index.html` file. The [Live Server](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) extension for VS Code is a great option.

### Running the Application

1.  **Clone the repository:**
    ```bash
    git clone <your-repo-url>
    cd <your-repo-directory>
    ```

2.  **(Optional) Set up Gemini API Key:**
    To use the "AI Wallet Security Report" feature, you need a Google Gemini API key. You must create a mechanism to expose this key as `process.env.API_KEY` to the browser environment. For local development, you could use a `.env` file and a tool like Vite, or temporarily hardcode it for testing purposes (not recommended for production).

3.  **Start a local server:**
    If you are using the "Live Server" extension in VS Code, simply right-click the `index.html` file and select "Open with Live Server".

The application should now be running and accessible in your browser, typically at `http://127.0.0.1:5500`.

## Project Structure

*   `index.html`: The main entry point of the application. Contains the import map for managing dependencies.
*   `index.tsx`: The root of the React application.
*   `/src`
    *   `/components`: Contains all React components, organized by feature (dashboard, layout, ui).
    *   `/context`: React context providers for managing global state (Audit Logs, Toasts).
    *   `/data`: Mock data for the application (scoring models).
    *   `/hooks`: Reusable custom React hooks (clipboard, wallet scoring).
    *   `/lib`: Core business logic and utility functions (scoring algorithm).
    *   `App.tsx`: The main App component that sets up the layout and providers.
    *   `types.ts`: TypeScript type definitions used throughout the project.
*   `/public`: Contains static assets like logos.
*   `/backend`: Contains documentation and assets related to the separate backend service (FastAPI).

This project was built to be a high-fidelity demonstration and a solid foundation for a production-grade application.